/*******************************************************************************
  Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
//#include "I2C1_USER.h"
#include "MCP23017Expander.h"
#include "string.h"

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
int i;
uint8_t Test_Data;
uint8_t RegData = 0;
uint8_t readBuffer[12];
uint8_t Result[10];
void Test_1();
void MCPREAD_Test();
uint8_t LRU_Response_Data[3] = {0, 0, 0};
#define N 3000  //count for do while
#define SWITCH_PRESSED_STATE 0
uint8_t Output_value[5];
uint8_t Dummy_Value[5] = {0x11, 0x22, 0x33, 0x44, 0x55};
uint8_t StartByte = 0x40;
uint8_t EndByte = 0x23;
void Switch_control();

void UART2_Callback(uintptr_t context)
{
    if (UART2_ErrorGet() != UART_ERROR_NONE)
    {
        //return UART_ERROR; //Handle error case
    }
    else
    {
        //Transfer completed successfully
    }
}

void UART3_Callback(uintptr_t context)
{
    if (UART3_ErrorGet() != UART_ERROR_NONE)
    {
        //return UART_ERROR; //Handle error case
    }
    else
    {
        //Transfer completed successfully
    }
}

int main(void)
{
    /* Initialize all modules */
    SYS_Initialize(NULL);
    CORETIMER_Start();
   // MCP23017Expander_Both_Initialize(SLAVE_ADDR_1, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1);
    MCP23017Expander_Both_Initialize(SLAVE_ADDR_5, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1);
    //MCP23017Expander_Both_Initialize(SLAVE_ADDR_3, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1);
    // MCP23017Expander_Both_Initialize(SLAVE_ADDR_2, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1);
    // MCP23017Expander_Both_Initialize ( SLAVE_ADDR_5, IODIRA_ADDR, IODIRA_Data2, IODIRB_ADDR, IODIRB_Data2 );
    // printf ( "MCP23017Expander_Initialize" );
    // GPIO_PinInterruptCallbackRegister ( PI_TRIGGER_1_PIN, Pin_Status_read, (uintptr_t) NULL );
    //GPIO_PinInterruptEnable ( PI_TRIGGER_1_PIN );




    while (true)
    {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks();
        // MCP23017Expander_WriteData ( SLAVE_ADDR_4, GPIOB_ADDR, 0xff );

        //CORETIMER_DelayMs ( 2000 );
        // MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOA_ADDR, 0x00 );
        // MCPREAD_Test ( );
        // UART2_Write ( Dummy_Value, sizeof (Dummy_Value ) );
        //CORETIMER_DelayMs ( 2000 );
        // Test_1 ( );
        // for ( i = 0; i <= N; i++ ) {
        Switch_control();

        //      }
        //printf ( "RegData = teat" );

        /*
        MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOA_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOB_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOA_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOB_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_3, GPIOA_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_3, GPIOB_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_4, GPIOA_ADDR, 0xff );
        MCP23017Expander_WriteData ( SLAVE_ADDR_4, GPIOB_ADDR, 0xff );

        CORETIMER_DelayMs ( 2000 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOA_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOB_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOA_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOB_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_3, GPIOA_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_3, GPIOB_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_4, GPIOA_ADDR, 0x00 );
        MCP23017Expander_WriteData ( SLAVE_ADDR_4, GPIOB_ADDR, 0x00 );
        CORETIMER_DelayMs ( 2000 );
         */

    }
    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE);
}

/*******************************************************************************
 End of File
 */

void Test_1()
{
    UART6_Read(&readBuffer, sizeof (readBuffer));
    /* Poll and wait for the transfer to complete */
    if (UART6_ErrorGet() != UART_ERROR_NONE)
    { // Error occurred while receiving the buffer

    }
    else
    { //  Received the buffer without any error

    }
    if (readBuffer[0] == 0x23)
    {
        for (i = 1; i <= 11; i++)
        {
            Result[i - 1] = readBuffer[i];
        }
        //CORETIMER_DelayMs ( 2000 ); 
    }
    /*
    res[0] = ( Result[1] & 0xFF );
    res[1] = ( ( Result[1] >> 8 )& 0xFF );
    res[2] = ( ( Result[1] >> 16 )& 0xFF );
    res[3] = ( ( Result[1] >> 24 ) & 0xFF );

    printf ( "B0=0x%02x\r\n", res[0] );
    printf ( "B1=0x%02x\r\n", res[1] );
    printf ( "B2=0x%02x\r\n", res[2] );
    printf ( "B3=0x%02x\r\n", res[3] );
     * */
    //UART6_Write ( Result, sizeof (Result ) );
    /*
    for ( i = 0; i <= 4; i++ ) {
        UART6_Write ( &Result[i], sizeof (Result[i] ) );
    }
   // UART6_Write ( &Result[0], sizeof (Result[0] ) );
    CORETIMER_DelayUs ( 2000 );
    
    Result1=( readBuffer[2] << 16 )& 0xff;
    // Result1=   (readBuffer[2] >> 3) & ((1 << 5)-1);
    Result1 = ( readBuffer[1] >> 3 );
    //  Result1 = readBuffer[2] & 0x1f;
    UART6_Write ( Result, sizeof (Result ) );
    UART6_Write ( &Result1, sizeof (Result1 ) );
    if((Result1&0xff)==0xf) {
    printf ( "pass" );
}
     * */
}

void MCPREAD_Test()
{
    /*
    LRU_Response_Data[0] = MCP23017Expander_ReadData ( SLAVE_ADDR_1, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR );
    LRU_Response_Data[1] = MCP23017Expander_ReadData ( SLAVE_ADDR_2, IODIRB_ADDR, IODIRB_Data2, GPIOB_ADDR );
    LRU_Response_Data[2] = MCP23017Expander_ReadData ( SLAVE_ADDR_2, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR );
     */

    LRU_Response_Data[0] = MCP23017Expander_ReadData(SLAVE_ADDR_5, IODIRB_ADDR, IODIRB_Data2, GPIOB_ADDR);
    LRU_Response_Data[1] = MCP23017Expander_ReadData(SLAVE_ADDR_5, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR);
    LRU_Response_Data[2] = MCP23017Expander_ReadData(SLAVE_ADDR_1, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR);
    LRU_Response_Data[0] = ~LRU_Response_Data[0];
    LRU_Response_Data[1] = ~LRU_Response_Data[1];
    LRU_Response_Data[2] = ~LRU_Response_Data[2];
    memcpy(&Output_value[0], &EndByte, sizeof (EndByte));
    memcpy(&Output_value[1], &LRU_Response_Data[0], sizeof (LRU_Response_Data));
    memcpy(&Output_value[2], &LRU_Response_Data[1], sizeof (LRU_Response_Data));
    memcpy(&Output_value[3], &LRU_Response_Data[2], sizeof (LRU_Response_Data));
    memcpy(&Output_value[4], &StartByte, sizeof (StartByte));
    //Switch_control();
    UART2_WriteCallbackRegister(UART2_Callback, (uintptr_t) NULL);
    UART3_WriteCallbackRegister(UART3_Callback, (uintptr_t) NULL);
    UART2_Write(Output_value, sizeof (Output_value));
    UART3_Write(Output_value, sizeof (Output_value));
    /**/

}

void Switch_control()
{
    printf("SWITCH CONTROL LOOP ");

   // MCP23017Expander_WriteData(SLAVE_ADDR_5, GPIOA_ADDR, LRU_Response_Data[0]);
  //  MCP23017Expander_WriteData(SLAVE_ADDR_5, GPIOB_ADDR, LRU_Response_Data[1]);
  //  MCP23017Expander_WriteData(SLAVE_ADDR_5, GPIOA_ADDR, LRU_Response_Data[2]);
     MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOB_ADDR, 0x00 );
     MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOA_ADDR, 0x00 );
  CORETIMER_DelayMs ( 2000 );
     MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOB_ADDR, 0xff );
     MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOA_ADDR, 0xff );
      CORETIMER_DelayMs ( 2000 );
    // MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOB_ADDR, 0x00 );
    // MCP23017Expander_WriteData ( SLAVE_ADDR_5, GPIOA_ADDR, 0x00 );
    // CORETIMER_DelayMs ( 2000 );
}