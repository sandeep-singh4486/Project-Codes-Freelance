D:\AFCS\Working Code

This folder contains the Final tested and working code related to AFCS.
1. AFCS_RTOS_TEST : Project folder contains initial demo and working of AFCS project with minimal( ALL Modules initialized but omly some implemented due to limitations on board) using RTOS. Pin Assignments are done according to schematic of new version). Tested Code Demo is in path D:\recording , AFCSv2testing.
2.AFCS_TEST : Project folder contains first version on AFCS.
3. MCP23017_TEST: Project folder contains LRU LED STATUS Read first version on AFCS.
4.PI196TEST : PI OPERATION code.

There are individual Driver Libraries for MCP23017 and MCP413X which you can add for the project if needed.