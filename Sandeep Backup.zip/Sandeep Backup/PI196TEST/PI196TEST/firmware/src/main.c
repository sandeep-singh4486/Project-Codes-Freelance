/*******************************************************************************
   Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c PI196 Operations

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <math.h>
#include "string.h"
//uint64_t Cell_Data_1[16] = { 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591 };
//uint64_t Cell_Data_2[16] = { 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591, 8589934591 };
//uint64_t Cell_Data_1[16] = {0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xAAAA5555, 0xAAAA5555, 0xAAAA5555, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA};
//uint64_t Cell_Data_2[16] = {0xFFFF0000, 0xFFFF0000, 0xFFFF0000, 0xAAAA5555, 0xAAAA5555, 0xAAAA5555, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA, 0xAAAAAAAA};
uint32_t Cell_Data_1[16] = { 0x010002C8, 0x00000001, 0x0C00008C, 0x00000001, 0x85E302BB, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001 };
uint32_t Cell_Data_2[16] = { 0xC8020001, 0x00000001, 0x0C00008C, 0x00000001, 0x85E302BB, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001, 0x00000001 };
//uint32_t Cell_Data_1[16] = { 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE };
//uint32_t Cell_Data_2[16] = { 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE };
//uint32_t Cell_Data_2[16] = { 0x00000001, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE, 0xFFFFFFFE };
uint8_t Cell_no;
uint8_t PI196_ReadBuffer[9];
uint8_t PI196_Unit;
uint8_t PI196_CellNum;
uint8_t PI196_Data[7];
uint8_t PI196_WVData[4];
uint32_t Temp = 0;
uint32_t Temp1 = 0;
uint8_t PI_2_PZPbit = 0;
void Func_Dec_2_Bin_JMR( uint32_t K1, uint32_t K2 );
void Wave_generate_PI196_JMR( );

void Wave_generate_PI196_01( );
void Wave_generate_PI196_02( );
//void Wave_generate();
void Wave_generate_PI196( );
void Func_Dec_2_Bin_01( uint64_t K );
void Func_Dec_2_Bin_02( uint64_t K );
void Func_PI196_Operation( );
void PI196_1_Operation( );
void PI196_2_Operation( );
void Clock_40Khz( ); //40khz pulse 32 pulse
int i, j, a, k, K = 0;

void UART2_Callback( uintptr_t context )
{
    if( UART2_ErrorGet( ) != UART_ERROR_NONE )
    {
        //Handle error case
    }
    else
    {

        //Transfer completed successfully
    }
}
// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************

int main( void )
{
    /* Initialize all modules */
    SYS_Initialize( NULL );

    CORETIMER_Start( );

    while( true )
    {
        SYS_Tasks( );
        //PZP_Trigger_Set ( );
        //SYS_Tasks ( );
        //PZP_Trigger_Set ( );
        // Func_PI196_Operation();
        Wave_generate_PI196( );


        /* else 
         {
             //      Wave_generate();
             Wave_generate_PI196 ( );


         }*/
    }

    /* Execution should not come here during normal operation */

    return( EXIT_FAILURE);
}

void Func_PI196_Operation( )
{
    UART2_ReadCallbackRegister( UART2_Callback, (uintptr_t) NULL );
    UART2_Read( &PI196_ReadBuffer, sizeof(PI196_ReadBuffer) ); /* Poll and wait for the transfer to complete */
    //TEST_LED_Set ( );
    /*
        if ( UART6_ErrorGet ( ) != UART_ERROR_NONE ) { // Error occurred while receiving the buffer

        } else { //  Received the buffer without any error

        }
     * */
    //Clock_40Khz();
    if( PI196_ReadBuffer[0] == 0x23 )
    {
        for( i = 1; i <= 7; i++ )
        {
            PI196_Data[i - 1] = PI196_ReadBuffer[i];
        }
        //CORETIMER_DelayMs ( 2000 ); 
    }
    for( j = 0; j <= 3; j++ )
    {

        PI196_WVData[j] = PI196_Data[j];

    }
    PI_2_PZPbit = PI196_Data[4];
    /*PI_2_PZPbit = PI196_Data[4];
        if ((PI_2_PZPbit)==0xff)
            {
             PZP_Trigger_Clear ( );   
            }
        else
        {
            PZP_Trigger_Set ( );
             PI196_1_Operation ( );
             PI196_2_Operation ( );
              Wave_generate_PI196 ( );
        }
     */
    UART2_Write( &PI196_Data, sizeof(PI196_Data) );
    // CORETIMER_DelayMs ( 1000 );

    /*switch ( PI_2_PZPbit ) {
       case 0xFF:
            PZP_Trigger_Clear ( );
           break;
        default:
            PZP_Trigger_Set ( );
            PI196_1_Operation ( );
            PI196_2_Operation ( );
             Wave_generate_PI196 ( );
           break;
        
   }*/
    PI196_Unit = ((PI196_Data[6]&0x01) | (PI196_Data[6]&0x02));
    //UART6_Write ( &PI196_Unit, sizeof (PI196_Unit ) );
    Wave_generate_PI196( );
    switch( PI196_Unit )
    {
    case 0x01:
        PI196_1_Operation( );
        Wave_generate_PI196( );
        //   Clock_40Khz();
        break;
    case 0x02:
        PI196_2_Operation( );
        Wave_generate_PI196( );
        // Clock_40Khz();
        break;
    default:
        Wave_generate_PI196( );
        break;
    }
}

/*******************************************************************************
 End of File
 */

void PI196_1_Operation( )
{

    // if ( PI_2_PZPbit == 0xff ) {
    //   PZP_Trigger_Clear ( );
    //}
    // else {
    // CORETIMER_DelayMs ( 2000 );
    //   PZP_Trigger_Set ( );
    //}

    PI196_CellNum = PI196_Data[5];
    switch( PI196_CellNum )
    {
    case 0x00:
        if( PI_2_PZPbit == 0xFF )
        {
            for( i = 0; i <= 16; i++ )
            {
                // Cell_Data_1[i]=0xFFFFFFFF;
                Cell_Data_1[i] = 0x00000001;
            }

        }
        memcpy( &Cell_Data_1[0], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x10:
        memcpy( &Cell_Data_1[1], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x20:
        memcpy( &Cell_Data_1[2], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x30:
        memcpy( &Cell_Data_1[3], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x40:
        memcpy( &Cell_Data_1[4], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x50:
        memcpy( &Cell_Data_1[5], &PI196_WVData, sizeof(PI196_WVData) );
        //  Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x60:
        memcpy( &Cell_Data_1[6], &PI196_WVData, sizeof(PI196_WVData) );
        //  Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x70:
        memcpy( &Cell_Data_1[7], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x01:
        memcpy( &Cell_Data_1[8], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x11:
        memcpy( &Cell_Data_1[9], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x21:
        memcpy( &Cell_Data_1[10], &PI196_WVData, sizeof(PI196_WVData) );
        //   UART2_Write ( &Cell_Data_1[10], sizeof (Cell_Data_1 ) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x31:
        memcpy( &Cell_Data_1[11], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x41:
        memcpy( &Cell_Data_1[12], &PI196_WVData, sizeof(PI196_WVData) );
        //  Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x51:
        memcpy( &Cell_Data_1[13], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x61:
        memcpy( &Cell_Data_1[14], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    case 0x71:
        memcpy( &Cell_Data_1[15], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_01 ( );
        Wave_generate_PI196( );
        break;
    default:
        if( PI_2_PZPbit == 0xFF )
        {
            for( i = 0; i <= 16; i++ )
            {
                // Cell_Data_1[i]=0xFFFFFFFF;
                Cell_Data_1[i] = 0x00000001;
            }
        }

        Wave_generate_PI196( );
        break;
    }
}

void PI196_2_Operation( )
{

    // if ( PI_2_PZPbit == 0xff ) {
    //   PZP_Trigger_Clear ( );
    //} //else {
    // PZP_Trigger_Set ( );
    // }
    //    if (PI_2_PZPbit=0xff)
    // {

    // }
    // else
    //  {

    //  }
    PI196_CellNum = PI196_Data[5];
    //UART2_Write ( &PI196_testBuffer2, sizeof (PI196_testBuffer2 ) );
    //UART2_Write ( &PI196_CellNum, sizeof (PI196_CellNum ) );
    switch( PI196_CellNum )
    {
    case 0x00:
        if( PI_2_PZPbit == 0xFF )
        {
            for( i = 0; i <= 16; i++ )
            {
                // Cell_Data_1[i]=0xFFFFFFFF;
                Cell_Data_2[i] = 0x00000001;
            }

        }

        memcpy( &Cell_Data_2[0], &PI196_WVData, sizeof(PI196_WVData) );

        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x10:
        memcpy( &Cell_Data_2[1], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x20:
        memcpy( &Cell_Data_2[2], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x30:
        memcpy( &Cell_Data_2[3], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x40:
        memcpy( &Cell_Data_2[4], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x50:
        memcpy( &Cell_Data_2[5], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x60:
        memcpy( &Cell_Data_2[6], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x70:
        memcpy( &Cell_Data_2[7], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x01:
        memcpy( &Cell_Data_2[8], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x11:
        memcpy( &Cell_Data_2[9], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x21:
        memcpy( &Cell_Data_2[10], &PI196_WVData, sizeof(PI196_WVData) );
        // UART2_Write ( &Cell_Data_2[10], sizeof (Cell_Data_2 ) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x31:
        memcpy( &Cell_Data_2[11], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x41:
        memcpy( &Cell_Data_2[12], &PI196_WVData, sizeof(PI196_WVData) );
        //Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x51:
        memcpy( &Cell_Data_2[13], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x61:
        memcpy( &Cell_Data_2[14], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    case 0x71:
        memcpy( &Cell_Data_2[15], &PI196_WVData, sizeof(PI196_WVData) );
        // Wave_generate_PI196_02 ( );
        Wave_generate_PI196( );
        break;
    default:
        if( PI_2_PZPbit == 0xFF )
        {
            for( i = 0; i <= 16; i++ )
            {
                // Cell_Data_1[i]=0xFFFFFFFF;
                Cell_Data_2[i] = 0x00000001;
            }
        }

        Wave_generate_PI196( );
        break;
    }
    // printf ( "unit2" );
}

/*
void Func_Dec_2_Bin_01 ( uint64_t K ) {
    for ( a = 32; a >= 0; a-- ) {
        k = K>>a;
        if ( k & 1 ) {
            LED1_Set ( );
          //  LED2_Set ( );
            CORETIMER_DelayUs ( 12 );
            //LED1_Clear( );
           // LED2_Clear ( );
           // CORETIMER_DelayUs ( 12 );
         // LED1_Clear ( );
        } else {
            LED1_Clear ( );
           // LED2_Set ( );
          //  CORETIMER_DelayUs ( 12 );
           // LED1_Clear( );
           // LED2_Clear ( );
            CORETIMER_DelayUs ( 12 );
            Clock_40Khz();
        }
    }
}

void Clock_40Khz ( ) {
    
        
   // for ( i = 0; i <= 32; i++ ) {
   //     Func_Dec_2_Bin_01 ( Cell_Data[i] );
   //     CORETIMER_DelayUs ( 12 );
   // }
    
    //  Func_PI196_Operation();
   // CORETIMER_DelayUs ( 750 );
//}
  //  PI196_1_Operation ( );
for ( i = 0; i <= 32; i++ ) {
    //LED1_Set ( );
    LED2_Set ( );
    CORETIMER_DelayUs ( 12 );
    //LED1_Clear ( );
    LED2_Clear ( );
    CORETIMER_DelayUs ( 12 );
}
//LED1_Clear ( );
CORETIMER_DelayUs ( 750 );
}

 */

void Func_Dec_2_Bin_01( uint64_t K )
{
    for( a = 31; a >= 0; a-- )
    {
        k = K>>a;
        if( k & 1 )
        {
            // LED1_Set ( );
            PI_196_01_KCA_Set( ); //PI_196_02_Clear ( );
            // LED2_Set ( );
            PI_196_CLK_Set( );
            //  LED2_Set ( );
            CORETIMER_DelayUs( 10 );
            // LED2_Clear ( );
            PI_196_CLK_Clear( );
            CORETIMER_DelayUs( 10 );
        }
        else
        {
            // LED1_Clear ( );
            PI_196_01_KCA_Clear( );
            ///PI_196_02_Set ( );
            // LED2_Set ( );
            PI_196_CLK_Set( );
            CORETIMER_DelayUs( 10 );
            // LED2_Clear ( );
            PI_196_CLK_Clear( );
            CORETIMER_DelayUs( 10 );
            //  Clock_40Khz ( );
        }
    }
    //LED1_Clear ( );
    PI_196_01_KCA_Clear( );
    PI_196_02_KCA_Clear( );
    CORETIMER_DelayUs( 850 );
}

void Func_Dec_2_Bin_02( uint64_t K )
{
    for( a = 31; a >= 0; a-- )
    {
        k = K>>a;
        if( k & 1 )
        {
            // LED1_Set ( );
            PI_196_02_KCA_Set( ); //PI_196_01_KCA_Clear ( );
            // LED2_Set ( );
            PI_196_CLK_Set( );
            //  LED2_Set ( );
            CORETIMER_DelayUs( 13 );
            // LED2_Clear ( );
            PI_196_CLK_Clear( );
            CORETIMER_DelayUs( 13 );
        }
        else
        {
            //LED1_Clear ( );
            PI_196_02_KCA_Clear( ); //PI_196_01_KCA_Set ( );
            // LED2_Set ( );
            PI_196_CLK_Set( );
            CORETIMER_DelayUs( 13 );
            // LED2_Clear ( );
            PI_196_CLK_Clear( );
            CORETIMER_DelayUs( 13 );
            //  Clock_40Khz ( );
        }
    }
    //LED1_Clear ( );
    PI_196_02_KCA_Clear( );
    PI_196_01_KCA_Clear( );
    CORETIMER_DelayUs( 830 );
}

void Func_Dec_2_Bin_JMR( uint32_t K1, uint32_t K2 )
{
    int ktemp1;
    int ktemp2;
    for( a = 31; a >= 0; a-- )
        //for ( a = 0; a <=31; a++ ) 
    {
        // ktemp1 = K1<<a;
        //ktemp2 = K2<<a;
        ktemp1 = K1>>a;
        ktemp2 = K2>>a;
        if( ktemp1 & 1 )
        {
            PI_196_01_KCA_Set( );
            PI_196_01_KCB_Clear( );
        }
        else
        {
            PI_196_01_KCA_Clear( );
            PI_196_01_KCB_Set( );
        }

        if( ktemp2 & 1 )
        {
            PI_196_02_KCA_Set( );
            PI_196_02_KCB_Clear( );
        }
        else
        {
            PI_196_02_KCA_Clear( );
            PI_196_02_KCB_Set( );
        }
        PI_196_CLK_Set( );PI_196_CLK1_Set( );
        CORETIMER_DelayUs( 13 );
        PI_196_CLK_Clear( );PI_196_CLK1_Clear( );
        CORETIMER_DelayUs( 13 );
       
    }
    PI_196_01_KCB_Set( );
    PI_196_02_KCB_Set( );
    PI_196_02_KCA_Clear( );
    PI_196_01_KCA_Clear( );
    CORETIMER_DelayUs( 820 );
}

void Wave_generate_PI196_JMR( )
{
    for( i = 0; i <= 15; i++ )
    {
        Func_Dec_2_Bin_JMR( Cell_Data_1[i], Cell_Data_2[i] );
    }
}

void Wave_generate_PI196_01( )
{
    for( i = 0; i <= 15; i++ )
    {
        Func_Dec_2_Bin_01( Cell_Data_1[i] );
    }
}

void Wave_generate_PI196_02( )
{
    for( i = 0; i <= 15; i++ )
    {
        Func_Dec_2_Bin_02( Cell_Data_2[i] );
    }
}

//void Wave_generate()
//{
//Wave_generate_PI196_01 ( );
//Wave_generate_PI196_02 ( );
//  Wave_generate_PI196_JMR();
//}

void Wave_generate_PI196( )
{
    Wave_generate_PI196_JMR( );
    /*
    for (i = 0; i <= 15; i++)
    {
        
        Func_Dec_2_Bin_01(Cell_Data_1[i]);
        Func_Dec_2_Bin_02(Cell_Data_2[i]);
        
    }
     */
}

