#include "MCP413X.h"
#include "Project_Main.h"

void Digipot1_Write ( uint8_t Value ) {
    wrdata[0] =0x00;
    wrdata[1] = Value;
    SPI3_CS1_Clear ( );
    SPI3_Write ( &wrdata, sizeof (wrdata ) );
    SPI3_CS1_Set ( );
}
void Digipot2_Write ( uint8_t Value ) {
    wrdata[0] =0x00;
    wrdata[1] = Value;
    SPI3_CS2_Clear ( );
    SPI3_Write ( &wrdata, sizeof (wrdata ) );
    SPI3_CS2_Set ( );
}
void Digipot3_Write ( uint8_t Value ) {
    wrdata[0] =0x00;
    wrdata[1] = Value;
    SPI3_CS3_Clear ( );
    SPI3_Write ( &wrdata, sizeof (wrdata ) );
    SPI3_CS3_Set ( );
}
void Digipot4_Write ( uint8_t Value ) {
    wrdata[0] =0x00;
    wrdata[1] = Value;
    SPI3_CS4_Clear ( );
    SPI3_Write ( &wrdata, sizeof (wrdata ) );
    SPI3_CS4_Set ( );
}
void Digipot5_Write ( uint8_t Value ) {
    wrdata[0] =0x00;
    wrdata[1] = Value;
    SPI3_CS5_Clear ( );
    SPI3_Write ( &wrdata, sizeof (wrdata ) );
    SPI3_CS5_Set ( );
}