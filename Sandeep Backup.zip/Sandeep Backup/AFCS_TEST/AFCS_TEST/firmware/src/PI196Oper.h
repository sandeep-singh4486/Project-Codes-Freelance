void Wave_generate_PI196_01 ( );
void Wave_generate_PI196_02 ( );
void Func_Dec_2_Bin_01 ( uint64_t K );
void Func_Dec_2_Bin_02 ( uint64_t K );
void Func_PI196_Operation ( );
void PI196_1_Operation ( );
void PI196_2_Operation ( );
void Func_Dec_to_Bin_01 ( uint64_t K, uint64_t L );
void Func_Dec_to_Bin_02 ( uint64_t K, uint64_t L );
void Wave_generate_PI196 ( );
void Clock_40Khz ( ); //40khz pulse 32 pulse
uint8_t Cell_no;
uint8_t PI196_ReadBuffer[9];
uint8_t PI196_Unit;
uint8_t PI196_CellNum;
uint8_t PI196_Data[7];
uint8_t PI196_WVData[5];