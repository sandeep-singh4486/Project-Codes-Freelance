/* ************************************************************************** */
/** Descriptive File Name

  @Company
 STPL

  @File Name
    PROJECTMAIN.c

  @Summary
    Brief description of the file.
 * This has the main project application code
  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */
/* ************************************************************************** */

/* This section lists the other files that are included in this file.
 */

/* TODO:  Include other files here if needed. */

#include "Project_Main.h"
#include "string.h"
//#include "PI196Oper.h"
/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */
/** Descriptive Data Item Name

  @Summary
    Brief one-line summary of the data item.
    
  @Description
    Full description, explaining the purpose and usage of data item.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.
    
  @Remarks
    Any additional remarks
 */

/* ************************************************************************** */
/* ************************************************************************** */
// Section: Local Functions                                                   */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

/* ************************************************************************** */

/** 
  @Function
    int ExampleLocalFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Description
    Full description, explaining the purpose and usage of the function.
    <p>
    Additional description in consecutive paragraphs separated by HTML 
    paragraph breaks, as necessary.
    <p>
    Type "JavaDoc" in the "How Do I?" IDE toolbar for more information on tags.

  @Precondition
    List and describe any required preconditions. If there are no preconditions,
    enter "None."

  @Parameters
    @param param1 Describe the first parameter to the function.
    
    @param param2 Describe the second parameter to the function.

  @Returns
    List (if feasible) and describe the return values of the function.
    <ul>
      <li>1   Indicates an error occurred
      <li>0   Indicates an error did not occur
    </ul>

  @Remarks
    Describe any special behavior not described above.
    <p>
    Any additional remarks.

  @Example
    @code
    if(ExampleFunctionName(1, 2) == 0)
    {
        return 3;
    }
 
static int ExampleLocalFunction ( int param1, int param2 ) {
    return 0;
}

 */
/* ************************************************************************** */
/* ************************************************************************** */
// Section: Interface Functions                                               */
/* ************************************************************************** */
/* ************************************************************************** */

/*  A brief description of a section can be given directly below the section
    banner.
 */

// *****************************************************************************

/** 
  @Function
    int ExampleInterfaceFunctionName ( int param1, int param2 ) 

  @Summary
    Brief one-line description of the function.

  @Remarks
    Refer to the example_file.h interface header for function usage details.
 
int ExampleInterfaceFunction ( int param1, int param2 ) {
    return 0;
}

 */
/* *****************************************************************************
 End of File
 */

//signed int AVal = 0;

uint8_t DigipotValue[5] = { 0 };
uint8_t SwitchValue[5] = { 0 };
uint8_t LRU_Response_Data[3];
uint8_t Output_value[] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
uint8_t Dummy_Value[3] = { 0x99, 0xfE, 0xfE };

uint8_t Current = 0;
uint8_t StartByte = 0x40;
uint8_t EndByte = 0x23;

void fnMain_Project ( ) {

    //LRU_RESPONSE_DATA ( );
       PZP_Operation ( ); // 1st call in pzp operation.
    //CORETIMER_DelayMs ( 1000 );

    if ( UART1_ReceiverIsReady ( ) == true ) {
        //  printf("WaveGeneration");
        PZP_Operation ( );

    }

    /*
    else if ( UART2_ReceiverIsReady ( ) == true ) {
        Func_PI196_Operation ( );
        //printf ( " PI OPERATION" );
    }

    else {
        Wave_generate_PI196 ( );
        
        CORETIMER_DelayUs ( 1 );

    }
     * */
}

void Current_SensorRead ( ) {
    ADCHS_ChannelConversionStart ( ADCHS_CH6 );
    CSVal_Read = ADCHS_ChannelResultGet ( ADCHS_CH6 );
    //CSVal_Read = CSVal_Read - 0xc0;
    //UART6_Write ( &CSVal_Read, sizeof (CSVal_Read ) );
    // Current = ( ( ( CSVal_Read - 4095 )*0.00488 ) / 0.066 );
    //  printf ( "read= %02f\r", (float) Current );
    //printf ( "calc= %02d\r\n", CSVal );
    // CORETIMER_DelayMs ( 1000 );
}

void DigiPot_ADC ( ) {
    ADCHS_ChannelConversionStart ( ADCHS_CH4 ); //A0
    ADCHS_ChannelConversionStart ( ADCHS_CH29 ); //A1
    ADCHS_ChannelConversionStart ( ADCHS_CH8 ); //A2
    ADCHS_ChannelConversionStart ( ADCHS_CH38 ); //A3
    ADCHS_ChannelConversionStart ( ADCHS_CH39 ); //A4

    Adc_Val[0] = ADCHS_ChannelResultGet ( ADCHS_CH4 );
    Adc_Val[1] = ADCHS_ChannelResultGet ( ADCHS_CH29 );
    Adc_Val[2] = ADCHS_ChannelResultGet ( ADCHS_CH8 );
    Adc_Val[3] = ADCHS_ChannelResultGet ( ADCHS_CH38 );
    Adc_Val[4] = ADCHS_ChannelResultGet ( ADCHS_CH39 );

    Vin[0] = (float) Adc_Val[0] * ADC_VREF / ADC_MAX_COUNT;
    Vin[1] = (float) Adc_Val[1] * ADC_VREF / ADC_MAX_COUNT;
    Vin[2] = (float) Adc_Val[2] * ADC_VREF / ADC_MAX_COUNT;
    Vin[3] = (float) Adc_Val[3] * ADC_VREF / ADC_MAX_COUNT;
    Vin[4] = (float) Adc_Val[4] * ADC_VREF / ADC_MAX_COUNT;
    //printf ( "V0 = %02X V1 = %02X V2 = %02X V3 = %02X ,V4 = %02X \n\r", (int) Vin[0], (int) Vin[1], (int) Vin[2], (int) Vin[3], (int) Vin[4] );
    // printf ( "DPV = %02d ,DPVHEX =  0x%02x\n\r", (int)Vin[0], (int)Vin[0] );
    //printf ( "$%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X#\n\r", (int) Vin[0], (int) Vin[1], (int) Vin[2], (int) Vin[3], (int) Vin[4],(int) Vin[0], (int) Vin[1], (int) Vin[2], (int) Vin[3], (int) Vin[4] , (int) Vin[4] );
}

void Read_DCVOLT ( ) {
    ADCHS_ChannelConversionStart ( ADCHS_CH5 );
    Adc_Val[6] = ADCHS_ChannelResultGet ( ADCHS_CH5 );
    Voltage_DC = (float) Adc_Val[6] * Volt_27 / ADC_MAX_COUNT;
    //  UART6_Write ( &Voltage_DC, sizeof (Voltage_DC ) );
    // printf ( "Voltage_DCDEC = %02d ,Voltage_DCHEX =  0x%02x\n\r", Voltage_DC, Adc_Val[6] );
}

void Read_ACVOLT ( ) {
    ADCHS_ChannelConversionStart ( ADCHS_CH42 );
    Adc_Val[5] = ADCHS_ChannelResultGet ( ADCHS_CH42 );
    Voltage_AC = (float) Adc_Val[5] * Volt_220 / ADC_MAX_COUNT;
    // printf ( "Voltage_ACDEC = %02d ,Voltage_ACHEX =  0x%02x\n\r", Voltage_AC, Adc_Val[5] );
}

void LRU_RESPONSE_DATA ( ) {
    LRU_Response_Data[1] = MCP23017Expander_ReadData_Reg ( SLAVE_ADDR_4, IODIRB_ADDR, IODIRB_Data2, GPIOB_ADDR );
    LRU_Response_Data[0] = MCP23017Expander_ReadData_Reg ( SLAVE_ADDR_4, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR );
    LRU_Response_Data[2] = MCP23017Expander_ReadData_Reg ( SLAVE_ADDR_3, IODIRA_ADDR, IODIRA_Data2, GPIOA_ADDR );
    LRU_Response_Data[0] = ~LRU_Response_Data[0];
    LRU_Response_Data[1] = ~LRU_Response_Data[1];
    LRU_Response_Data[2] = ~LRU_Response_Data[2];

    // printf ( "MCPPORTVALUE = 0x%02x%02x%02x\r\n", LRU_Response_Data[2], LRU_Response_Data[1], LRU_Response_Data[0] );
    //printf ( "MCPPORTVALUE = 0x%02x%02x\r\n", LRU_Response_Data[1],LRU_Response_Data[0] );
}

void Receive_Data_Parse ( ) {
    UART1_Read ( &readBuffer, sizeof (readBuffer ) );
    /* Poll and wait for the transfer to complete */
    if ( UART1_ErrorGet ( ) != UART_ERROR_NONE ) { // Error occurred while receiving the buffer

    } else { //  Received the buffer without any error

    }
    //UART6_Write ( &readBuffer, sizeof (readBuffer ) );

    if ( readBuffer[0] == 0x23 ) {
        for ( i = 1; i <= 10; i++ ) {
            Result[i - 1] = readBuffer[i];
        }

        //CORETIMER_DelayMs ( 2000 ); 
    }
    // UART6_Write ( &Result, sizeof (Result ) );


    for ( j = 0; j <= 4; j++ ) {

        DigipotValue[j] = Result[j];

    }

    for ( j = 0; j <= 4; j++ ) {

        SwitchValue[j] = Result[9 - j];

    }

    Digital_PotControl ( );
    MCP23017_SWITCHControl ( );
}

void Digital_PotControl ( ) {
    Digipot1_Write ( DigipotValue[4] );
    Digipot2_Write ( DigipotValue[3] );
    Digipot3_Write ( DigipotValue[2] );
    Digipot4_Write ( DigipotValue[1] );
    Digipot5_Write ( DigipotValue[0] );

}

void MCP23017_SWITCHControl ( ) {
    /*    for ( i = 1; i <= 4; i++ ) {
            switch ( SwitchValue[i] ) {
                case 0x01:
                    SwitchValue[i] = 0x01;
                    break;
                case 0x02:
                    SwitchValue[i] = 0x02;
                    break;
                case 0x03:
                    SwitchValue[i] = 0x04;
                    break;
                case 0x04:
                    SwitchValue[i] = 0x08;
                    break;
                case 0x05:
                    SwitchValue[i] = 0x10;
                    break;
                case 0x06:
                    SwitchValue[i] = 0x20;
                    break;
                case 0x07:
                    SwitchValue[i] = 0x40;
                    break;
                case 0x08:
                    SwitchValue[i] = 0x80;
                    break;
            }
        }*/
    MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOB_ADDR, SwitchValue[0] );
    MCP23017Expander_WriteData ( SLAVE_ADDR_1, GPIOA_ADDR, SwitchValue[1] );
    MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOB_ADDR, SwitchValue[2] );
    MCP23017Expander_WriteData ( SLAVE_ADDR_2, GPIOA_ADDR, SwitchValue[3] );
    MCP23017Expander_WriteData ( SLAVE_ADDR_3, GPIOB_ADDR, SwitchValue[4] );
    //   printf ( "MCPPORTVALUE = 0x%02x%02x%02x%02x%02x\n\r", SwitchValue[0], SwitchValue[1], SwitchValue[2], SwitchValue[3], SwitchValue[4] );
    //   printf ( "DIGIPOT = 0x%02x%02x%02x%02x%02x\n\r", DigipotValue[0], DigipotValue[1], DigipotValue[2], DigipotValue[3], DigipotValue[4] );
}

void PZP_Operation ( ) {

    Receive_Data_Parse ( );
    LRU_RESPONSE_DATA ( );
    Current_SensorRead ( );
    memcpy ( &Output_value[0], &EndByte, sizeof (EndByte ) );
    memcpy ( &Output_value[1], &DigipotValue[0], sizeof (DigipotValue ) );
    memcpy ( &Output_value[2], &DigipotValue[1], sizeof (DigipotValue ) );
    memcpy ( &Output_value[3], &DigipotValue[2], sizeof (DigipotValue ) );
    memcpy ( &Output_value[4], &DigipotValue[3], sizeof (DigipotValue ) );
    memcpy ( &Output_value[5], &DigipotValue[4], sizeof (DigipotValue ) );
    memcpy ( &Output_value[6], &CSVal_Read, sizeof (CSVal_Read ) ); //current
    memcpy ( &Output_value[7], &Dummy_Value[1], sizeof (Dummy_Value ) ); //Voltage_DC
    memcpy ( &Output_value[8], &Dummy_Value[2], sizeof (Dummy_Value ) ); //Voltage_AC
    memcpy ( &Output_value[9], &LRU_Response_Data[0], sizeof (LRU_Response_Data ) );
    memcpy ( &Output_value[10], &LRU_Response_Data[1], sizeof (LRU_Response_Data ) );
    memcpy ( &Output_value[11], &LRU_Response_Data[2], sizeof (LRU_Response_Data ) );
    memcpy ( &Output_value[12], &StartByte, sizeof (StartByte ) );
    UART1_Write ( &Output_value, sizeof (Output_value ) );

}
