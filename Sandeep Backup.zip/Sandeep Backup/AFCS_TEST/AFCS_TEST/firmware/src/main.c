/*******************************************************************************
  Main Source File

  Company:
   STPL.

  File Name:
    main.c

  Summary:
    This file contains the "main" function for a project.

  Description:
    This file contains the "main" function for a project.  The
    "main" function calls the "SYS_Initialize" function to initialize the state
    machines of all modules in the system
 *******************************************************************************/

// *****************************************************************************
// *****************************************************************************
// Section: Included Files
// *****************************************************************************
// *****************************************************************************

#include "Project_Main.h"

// *****************************************************************************
// *****************************************************************************
// Section: Main Entry Point
// *****************************************************************************
// *****************************************************************************
  void MyI2CCallback(uintptr_t context)
{
    if(I2C1_ErrorGet() == I2C_ERROR_NONE)
    {
        //Transfer is completed successfully
    }
    else
    {
        //Error occurred during transfer.
    }
}
  void UART1_Callback(uintptr_t context)
{
    if(UART1_ErrorGet() != UART_ERROR_NONE)
    {
        //Handle error case
    }
    else
    {
    
        //Transfer completed successfully
    }
}
int main ( void ) {
    /* Initialize all modules */

    SYS_Initialize ( NULL );
    CORETIMER_Start ( );
    I2C1_CallbackRegister(MyI2CCallback, (uintptr_t)NULL);
    UART1_WriteCallbackRegister(UART1_Callback, (uintptr_t)NULL);
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_1, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_2, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_3, IODIRA_ADDR, IODIRA_Data2, IODIRB_ADDR, IODIRB_Data1 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_4, IODIRA_ADDR, IODIRA_Data2, IODIRB_ADDR, IODIRB_Data2 );
    //printf(" All modules initialized");
    //
    //MCP23017Expander1_Initialize ( );
    while (true) {
        /* Maintain state machines of all polled MPLAB Harmony modules. */
        SYS_Tasks ( );


        fnMain_Project ( );
    }

    /* Execution should not come here during normal operation */

    return ( EXIT_FAILURE );
}


/*******************************************************************************
 End of File
 */

