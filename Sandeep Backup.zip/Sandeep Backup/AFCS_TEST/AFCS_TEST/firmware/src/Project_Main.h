/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ****-********************************************************************** */

// Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include "MCP23017Expander.h"
#include "MCP413X.h"
#include <limits.h>


// Variables Definitions
uint8_t CSVal_Read, CSVal, Voltage_DC, Voltage_AC;
uint8_t Current;
uint8_t Adc_Val[8];
uint8_t DigitalPot_Val[5];
extern uint8_t Val;
int i, j, k;
uint8_t readBuffer[12];
uint8_t Result[10];
extern uint8_t DigipotValue[5];
extern uint8_t SwitchValue[5];

// Function Definitions

void fnMain_Project();
void Current_SensorRead();
void Read_DCVOLT();
void Read_ACVOLT();
void Receive_Data_Parse();
void LRU_RESPONSE_DATA();
void Digital_PotControl();
void MCP23017_SWITCHControl();
void ADC_Operation();
void PZP_Operation();
void DigiPot_ADC();
// Variables
#define BUFSIZE                 2
#define ADC_VREF                (3.3f)
#define ADC_MAX_COUNT           (1023)
#define Offset_Value            2500
#define sensitivity             185
#define Volt_27                 27
#define Volt_220                200

uint8_t wrdata[BUFSIZE];
float Vin[8];
uint8_t Result[10];
uint8_t DigipotValue[5];

//uint8_t Output_value[13]={EndByte,  Vin[0],  Vin[1],  Vin[2],  Vin[3],  Vin[4], Current,  Voltage_DC,  Voltage_AC,  LRU_Response_Data[2],  LRU_Response_Data[1],  LRU_Response_Data[0],StartByte };
uint8_t SwitchValue[5];
uint8_t Slave1_Data;
uint8_t Slave2_Data;
uint8_t Slave3_Data;

