#ifndef __MCP23017EXPANDER_H__
#define __MCP23017EXPANDER_H__
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes
#include <stdint.h>
#include "configuration.h"
#include "Project_Main.h"





#define IOCON_ADDR      0x0A
#define IOCON_Data      0x20
#define IOCON_Data1     0x00
#define GPPUA_ADDR      0x0C
#define GPPUA_Data      0xFF
#define IODIRA_ADDR     0x00
#define IODIRA_Data1     0x00
#define IODIRA_Data2     0xff
#define GPIOA_ADDR      0x12
#define GPIOB_ADDR      0x13
#define GPPUB_ADDR      0x0D
#define GPIOA_Data1      0x00
#define GPIOA_Data2      0xff
#define GPPUB_Data      0xFF
#define IODIRB_ADDR     0x01
#define IODIRB_Data1     0x00
#define IODIRB_Data2     0xff
#define OLATA_ADDR      0X14
#define OLATB_ADDR      0X15

#define SLAVE_ADDR_1   0x0020
#define SLAVE_ADDR_2   0x0021
#define SLAVE_ADDR_3   0x0022
#define SLAVE_ADDR_4   0x0023
//uint8_t IOCON_ADDR = 0x0A;
//uint8_t wrdata[BUFSIZE];


extern uint8_t RData;
extern uint8_t RData1;

//uint8_t myWriteData;

/*
void MCP23017Expander1_SLAVE_Initialize();
void MCP23017Expander1_WriteData(uint8_t WAddr, uint8_t WData);
void MCP23017Expander2_SLAVE_Initialize();
void MCP23017Expander1_SLAVE_WriteData(uint8_t WAddr, uint8_t WData);
void MCP23017Expander2_SLAVE_WriteData(uint8_t WAddr, uint8_t WData);
 */
void MCP23017Expander1_Initialize();
void MCP23017Expander2_Initialize();
void MCP23017Expander3_Initialize();
void MCP23017Expander4_Initialize();
void MCP23017Expander_Both_Initialize ( uint8_t Slave_Add, uint8_t PortAAdd, uint8_t PortAData, uint8_t PortBAdd, uint8_t PortBData ) ;
//void MCP23017Expander1_WriteData(uint8_t WAddr, uint8_t WData);
//void MCP23017Expander_PORTA_Initialize(uint8_t WAddr, uint8_t WData); //GPIO direction control whether I/0
void MCP23017Expander1_ReadData(uint8_t Regis_add);
void MCP23017Expander1_WriteData_PortA(uint8_t WData);
void MCP23017Expander1_WriteData_PortB(uint8_t WData);
void MCP23017Expander_Initialize(uint8_t Slave_Add, uint8_t PortAAdd, uint8_t PortAData, uint8_t PortBAdd, uint8_t PortBData);
void MCP23017Expander_WriteData(uint8_t Slave_Add, uint8_t Regis_add, uint8_t WData);
void MCP23017Expander_ReadData(uint8_t Slave_Add, uint8_t Regis_add, uint8_t WData);
//uint8_t MCP23017Expander_ReadData_Reg (uint8_t Slave_Add, uint8_t Regis_add );
uint8_t MCP23017Expander_ReadData_Reg (uint8_t Slave_Add,uint8_t PortAdd, uint8_t PortData , uint8_t Regis_add ); 

void MCP23017Expander_Init();
#endif