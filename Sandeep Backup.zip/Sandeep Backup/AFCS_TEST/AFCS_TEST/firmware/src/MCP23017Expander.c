#include "MCP23017Expander.h"
/*
uint8_t IOCON_ADDR = 0x0A;
uint8_t GPPUA_ADDR = 0x0C;
uint8_t IODIRA_ADDR = 0x00;
uint8_t GPIOA_ADDR = 0x12;
uint8_t GPIOB_ADDR = 0x13;
uint8_t GPPUB_ADDR = 0x0D;
uint8_t IODIRB_ADDR = 0x01;
uint8_t OLATA_ADDR = 0x14;
uint8_t OLATB_ADDR = 0x15;

uint8_t IOCON_Data = 0x20;
uint8_t GPPUA_Data = 0xFF;
uint8_t IODIRA_Data1 = 0x00;
uint8_t IODIRA_Data2 = 0xFF;
uint8_t GPIOA_Data1 = 0xFF;
uint8_t GPIOA_Data2 = 0x00;
uint8_t GPPUB_Data = 0xFF;
uint8_t IODIRB_Data1 = 0x00;
uint8_t IODIRB_Data2 = 0xFF;
 */
uint8_t RData;
uint8_t RData1;
uint8_t WrData;
// NOTE: I2C functions called here are Harmony-generated functions. No functions were used from I2C1_USER.c

/*
void MCP23017Expander1_Initialize ( ) {
    // Wait until bus is idle
    // NOTE: For non-interrupt driven code, this should be called after I2C1_Write()
    while (I2C1_IsBusy ( ));

    // Store data to be sent inside an array which will be passed to I2C1_Write()
    // NOTE: No need to store SLAVE_ADDR_1 inside the array, since it is passed as an argument
    // to I2C1_Write()

    
wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    // Call I2C1_Write() to send data
    I2C1_Write ( SLAVE_ADDR_1, IOCON_ADDR, 2 );
     while(I2C1_IsBusy());
    CORETIMER_DelayUs ( 250 );

    // Store next data to the array & call I2C1_Write()
    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    // Store next data to the array & call I2C1_Write()
    wrdata[0] = IODIRA_ADDR;
    wrdata[1] = IODIRA_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    // NOTE: No need to manually call functions like I2C1_start() or I2C1_stop()
    // The Harmony-generated functions generate the I2C start & stop bits


    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( IOCON_ADDR );
    //    I2C1_write ( IOCON_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );
    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( GPPUA_ADDR );
    //    I2C1_write ( GPPUA_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );
    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( IODIRA_ADDR );
    //    I2C1_write ( IODIRA_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );
}

void MCP23017Expander2_Initialize ( ) {
    uint8_t wrdata[BUFSIZE];


    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    wrdata[0] = GPPUB_ADDR;
    wrdata[1] = GPPUB_Data;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    wrdata[0] = IODIRB_ADDR;
    wrdata[1] = IODIRB_Data;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( IOCON_ADDR );
    //    I2C1_write ( IOCON_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );

    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( GPPUB_ADDR );
    //    I2C1_write ( GPPUB_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );

    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( IODIRB_ADDR );
    //    I2C1_write ( IODIRB_Data );
    //    I2C1_stop ( );
    //    CORETIMER_DelayUs ( 250 );
}

void MCP23017Expander1_WriteData ( uint8_t WAddr, uint8_t WData ) {
    uint8_t wrdata[BUFSIZE];

    while (I2C1_IsBusy ( ));

    MCP23017Expander1_Initialize ( );

    wrdata[0] = WAddr;
    wrdata[1] = WData;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));

    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( WAddr );
    //    I2C1_wait ( );
    //    I2C1_write ( WData );
    //    //I2C1TRN = WData;
    //    I2C1_stop ( );
}

void MCP23017Expander2_WriteData ( uint8_t WAddr, uint8_t WData ) {
    uint8_t wrdata[BUFSIZE];

    while (I2C1_IsBusy ( ));

    MCP23017Expander2_Initialize ( );

    wrdata[0] = WAddr;
    wrdata[1] = WData;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    while (I2C1_IsBusy ( ));

    //    MCP23017Expander1_Initialize ( );
    //    I2C1_start ( );
    //    I2C1_write ( SLAVE_ADDR_1 );
    //    I2C1_write ( WAddr );
    //    I2C1_wait ( );
    //    I2C1_write ( WData );
    //    //I2C1TRN = WData;
    //    I2C1_stop ( );
}

void MCP23017Expander1_SLAVE_Initialize ( ) {
    I2C2_WriteByte ( IOCON_ADDR );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C2_WriteByte ( IOCON_Data );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C2_WriteByte ( GPPUA_ADDR );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C2_WriteByte ( GPPUA_Data );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C2_WriteByte ( IODIRA_ADDR );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C2_WriteByte ( IODIRA_Data );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C2_WriteByte ( GPIOA_ADDR );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C2_WriteByte ( GPIOA_Data );
    while (I2C2_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
}
 */
void MCP23017Expander1_Initialize ( ) {

    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //CORETIMER_DelayUs ( 250 );


    /*
      wrdata[0] = GPIOA_ADDR;
        wrdata[1] = GPIOA_Data2;
        I2C1_Write ( SLAVE_ADDR_1, wrdata, 4 );
        while (I2C1_IsBusy ( ));
        CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
     */
}

void MCP23017Expander2_Initialize ( ) {

    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    //while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_2, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );


    /*
      wrdata[0] = GPIOA_ADDR;
        wrdata[1] = GPIOA_Data2;
        I2C1_Write ( SLAVE_ADDR_1, wrdata, 4 );
        while (I2C1_IsBusy ( ));
        CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
     */
}

void MCP23017Expander3_Initialize ( ) {

    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_3, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_3, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //CORETIMER_DelayUs ( 250 );


    /*
      wrdata[0] = GPIOA_ADDR;
        wrdata[1] = GPIOA_Data2;
        I2C1_Write ( SLAVE_ADDR_1, wrdata, 4 );
        while (I2C1_IsBusy ( ));
        CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
     */
}

void MCP23017Expander4_Initialize ( ) {

    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_4, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_4, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //   CORETIMER_DelayUs ( 250 );


    /*
      wrdata[0] = GPIOA_ADDR;
        wrdata[1] = GPIOA_Data2;
        I2C1_Write ( SLAVE_ADDR_1, wrdata, 4 );
        while (I2C1_IsBusy ( ));
        CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
     */
}

void MCP23017Expander1_WriteData_PortA ( uint8_t WData ) {


    wrdata[0] = IODIRA_ADDR;
    wrdata[1] = IODIRA_Data1;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );

    wrdata[0] = GPIOA_ADDR;
    wrdata[1] = WData;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //   CORETIMER_DelayMs ( 500 );

}

void MCP23017Expander1_WriteData_PortB ( uint8_t WData ) {


    wrdata[0] = IODIRA_ADDR;
    wrdata[1] = IODIRA_Data1;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );

    wrdata[0] = GPIOB_ADDR;
    wrdata[1] = WData;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayMs ( 500 );

}

/*
void MCP23017Expander_PORTA_Initialize ( uint8_t WAddr, uint8_t WData ) {

    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );


    wrdata[0] = WAddr;
    wrdata[1] = WData;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    
      wrdata[0] = GPIOA_ADDR;
        wrdata[1] = GPIOA_Data2;
        I2C1_Write ( SLAVE_ADDR_1, wrdata, 4 );
        while (I2C1_IsBusy ( ));
        CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IOCON_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &GPPUA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );

    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_ADDR, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
    I2C1_Write ( SLAVE_ADDR_1, &IODIRA_Data, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 250 );
     
}
 */
void MCP23017Expander1_ReadData ( uint8_t Regis_add ) {


    wrdata[0] = IODIRA_ADDR;
    wrdata[1] = IODIRA_Data2;
    I2C1_Write ( SLAVE_ADDR_1, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 1 );
    //WrData = Regis_add;
    I2C1_WriteRead ( SLAVE_ADDR_1, &Regis_add, 1, &RData, 1 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayUs ( 1 );
    //return RData;

}

void MCP23017Expander_Initialize ( uint8_t Slave_Add, uint8_t PortAAdd, uint8_t PortAData, uint8_t PortBAdd, uint8_t PortBData ) {
    //IODIRADDR,DATA
    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );

    wrdata[0] = GPPUB_ADDR;
    wrdata[1] = GPPUB_Data;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );

    wrdata[0] = PortAAdd;
    wrdata[1] = PortAData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );
    wrdata[0] = PortBAdd;
    wrdata[1] = PortBData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );
}

void MCP23017Expander_WriteData ( uint8_t Slave_Add, uint8_t Regis_add, uint8_t WData ) {
    //GPIO address, data
    wrdata[0] = Regis_add;
    wrdata[1] = WData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    CORETIMER_DelayMs ( 100 );

}

void MCP23017Expander_ReadData ( uint8_t Slave_Add, uint8_t Regis_add, uint8_t WData ) {

    wrdata[0] = IODIRA_ADDR;
    wrdata[1] = IODIRA_Data2;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );
    //WrData = Regis_add;
    I2C1_WriteRead ( Slave_Add, &Regis_add, 1, &RData, 1 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayMs ( 500 );

}

uint8_t MCP23017Expander_ReadData_Reg ( uint8_t Slave_Add, uint8_t PortAdd, uint8_t PortData, uint8_t Regis_add ) {
    wrdata[0] = PortAdd;
    wrdata[1] = PortData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );

    I2C1_WriteRead ( Slave_Add, &Regis_add, 1, &RData1, 1 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayMs ( 500 );
    //return 0xaa;
    return RData1;

}

void MCP23017Expander_Both_Initialize ( uint8_t Slave_Add, uint8_t PortAAdd, uint8_t PortAData, uint8_t PortBAdd, uint8_t PortBData ) {
    //IODIRADDR,DATA
    wrdata[0] = IOCON_ADDR;
    wrdata[1] = IOCON_Data1;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );


    wrdata[0] = GPPUA_ADDR;
    wrdata[1] = GPPUA_Data;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //CORETIMER_DelayUs ( 250 );

    wrdata[0] = GPPUB_ADDR;
    wrdata[1] = GPPUB_Data;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );

    wrdata[0] = PortAAdd;
    wrdata[1] = PortAData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    // CORETIMER_DelayUs ( 250 );
    wrdata[0] = PortBAdd;
    wrdata[1] = PortBData;
    I2C1_Write ( Slave_Add, wrdata, 2 );
    while (I2C1_IsBusy ( ));
    //  CORETIMER_DelayUs ( 250 );
}

void MCP23017Expander_Init ( ) {
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_1, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_2, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data1 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_3, IODIRA_ADDR, IODIRA_Data1, IODIRB_ADDR, IODIRB_Data2 );
    MCP23017Expander_Both_Initialize ( SLAVE_ADDR_4, IODIRA_ADDR, IODIRA_Data2, IODIRB_ADDR, IODIRB_Data2 );
    //  MCP23017Expander1_Initialize();
    //  MCP23017Expander2_Initialize();
    //  MCP23017Expander3_Initialize();
    //  MCP23017Expander4_Initialize();
}
