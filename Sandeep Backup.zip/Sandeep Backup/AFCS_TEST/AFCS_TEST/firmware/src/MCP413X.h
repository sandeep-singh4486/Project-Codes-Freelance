/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include "definitions.h"                // SYS function prototypes

void Digipot1_Write ( uint8_t Value );
void Digipot2_Write ( uint8_t Value );
void Digipot3_Write ( uint8_t Value );
void Digipot4_Write ( uint8_t Value );
void Digipot5_Write ( uint8_t Value );

/* *****************************************************************************
 End of File
 */
